create function prevent_timestamp_modification() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.created_at IS DISTINCT FROM OLD.created_at THEN
        RAISE EXCEPTION 'Modification de created_at interdite';
    END IF;
    IF NEW.updated_at IS DISTINCT FROM OLD.updated_at THEN
        RAISE EXCEPTION 'Modification manuelle de updated_at interdite';
    END IF;
    RETURN NEW;
END;
$$;

alter function prevent_timestamp_modification() owner to "default";

